Runs in p5.js
File -> open -> release/sketch.js -> play